const express = require('express');
const app = express();
const port = 4000;
const cors = require('cors');

app.use(cors())

app.get('/', (_, res) => {
  res.send('Hello world!')
});

app.post('/users', (_, res) => {
  res.json({ message: 'Posted!' });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
