# React 102

- Do an `npm i` or `npm ci` to install dependencies
- Start front-end code from a terminal with `npm start`, the front-end will be running on localhost:3000
- Each page is its own application, just replace it in `src/index.js` depending on what you want to see
- For page 6/7 regarding the API calls, open a separate terminal window and type `node server.js`. The server will be runnning on localhost:4000
