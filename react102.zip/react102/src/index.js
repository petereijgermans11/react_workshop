import React from 'react';
import ReactDOM from 'react-dom';
import Page1 from './Page1';

ReactDOM.render(
  <Page1 />,
  document.getElementById('root')
);
