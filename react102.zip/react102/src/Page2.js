import { useState } from 'react';

const AnotherComponent = (props) => {
  return (
    <div>AnotherComponent: {props.count}</div>
  )
}

const Component = () => {
  const [count, setCount] = useState(0);

  return (
    <section>
      <AnotherComponent count={count} />
      <button onClick={() => setCount(count + 1)}>{count}</button>
    </section>
  );
};

const Page2 = () => {
  return (
    <main>
      <h1>My application</h1>
      <Component />
    </main>
  );
};

export default Page2;
