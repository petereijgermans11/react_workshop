import { configureStore, createSlice } from "@reduxjs/toolkit";
import { Provider, useDispatch, useSelector } from 'react-redux';

const slice = createSlice({
  name: 'countSlice',
  initialState: { count: 0 },
  reducers: {
    increment: (state) => { state.count += 1 },
  },
});

const store = configureStore({ reducer: slice.reducer });

const increment = slice.actions.increment;

const Component = () => {
  const count = useSelector(state => state.count);

  const dispatch = useDispatch();

  return (
    <button onClick={() => dispatch(increment())}>{count}</button>
  );
};

const Page5 = () => {
  return (
    <Provider store={store}>
      <Component />
    </Provider>
  );
};

export default Page5;
