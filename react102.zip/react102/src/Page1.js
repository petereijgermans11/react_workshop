import { useState } from 'react';

const Component = () => {
  const [count, setCount] = useState(0);

  return (
    <button onClick={() => setCount(count + 1)}>{count}</button>
  );
};

const Page1 = () => {
  return (
    <main>
      <h1>My application</h1>
      <Component />
    </main>
  );
};

export default Page1;
