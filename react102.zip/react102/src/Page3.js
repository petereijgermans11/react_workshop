import { useState } from 'react';

const AnotherComponent1 = (props) => {
  return (
    <div>AnotherComponent: {props.count}</div>
  );
};

const AnotherComponent2 = (props) => {
  return (
    <button onClick={props.increment}>Increment Count</button>
  );
};

const Component = () => {
  const [count, setCount] = useState(0);

  return (
    <section>
      <AnotherComponent1 count={count} />
      <AnotherComponent2 increment={() => setCount(count + 1)} />
    </section>
  );
};

const Page3 = () => {
  return (
    <main>
      <h1>My application</h1>
      <Component />
    </main>
  );
};

export default Page3;
