import { useEffect } from "react";
import axios from "axios";

const Page6 = () => {
  useEffect(() => {
    axios.post('http://localhost:4000/users', { name: 'Robert' })
      .then(res => console.log(res.data));
  }, []);

  return (
    <div />
  );
};

export default Page6;
