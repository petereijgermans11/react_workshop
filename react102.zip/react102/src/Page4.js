import { createContext, useContext, useState } from 'react';


const GlobalCount = createContext();

const Component = () => {
  const [count, increment] = useContext(GlobalCount);

  return (
    <button onClick={increment}>Increment context count {count}</button>
  );
};

const Page4 = () => {
  const [count, setCount] = useState(0);
  const increment = () => setCount(count + 1);

  return (
    <GlobalCount.Provider value={[count, increment]}>
      <Component />
    </GlobalCount.Provider>
  );
};

export default Page4;
