import { useEffect } from "react";

const Page6 = () => {
  useEffect(() => {
    fetch('http://localhost:4000/users', {
      method: 'POST',
      body: JSON.stringify({ name: 'Robert' }),
    })
      .then((res) => res.json())
      .then(console.log);
  }, []);

  return (
    <div />
  );
};

export default Page6;
